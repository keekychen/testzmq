# Trademark notice

Node.js is a trademark of Joyent, Inc. and is used with its permission. We are
not endorsed by or affiliated with Joyent. 

# Files

## From the repository for the Node.js website
- [LICENSE](https://github.com/nodejs/nodejs.org/blob/master/LICENSE)
- [js-green.svg](https://github.com/nodejs/nodejs.org/blob/master/static/images/logos/js-green.svg)

## Generated using [rsvg-convert](http://live.gnome.org/LibRsvg)
- [js-green-32x32.png](js-green-32x32.png)
- [js-green-64x64.png](js-green-64x64.png)

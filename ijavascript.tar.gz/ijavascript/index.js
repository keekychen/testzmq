// Do not `require("ijavascipt")`
// Please `require("jp-kernel")` instead
// This is only a hack to support https://github.com/nteract/nteract/pull/1339
module.exports = require("jp-kernel");
